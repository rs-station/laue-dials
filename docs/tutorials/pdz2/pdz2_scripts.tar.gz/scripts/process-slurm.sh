#!/bin/bash

#this is a script that processes all image series simultaneously, with the help of slurm.

#these start-angles and sweep angles are to be manually input by the user using information from their particular experimental design. 
declare -A START_ANGLES=( ["c"]=0 ["d"]=92 ["e"]=181 ["f"]=361.5)
declare -A OSCS=( ["c"]=2 ["d"]=2 ["e"]=2 ["f"]=1)



# to use: do not run both blocks simultaneously. instead, wait for the jobs of the first block to finish before uncommenting the second block. 
gain=0.3


# RUN THIS FIRST!

#############
# block 1   #
#############

# for pass in c d e f 
# do
#     if [ $pass == e ];then 
#         sbatch scripts/one_pass-from_off.sh $pass off ${START_ANGLES[$pass]} ${OSCS[$pass]} $gain -x,y,-z
#     else
#         sbatch scripts/one_pass-from_off.sh $pass off ${START_ANGLES[$pass]} ${OSCS[$pass]} $gain x,y,z
#     fi
# done

# RUN THIS SECOND!
#############
# block 2   #
#############

for delay in off 50ns 100ns 200ns
do 
    for pass in c d e f 
    do
        if [ $pass == d ];then
            sbatch scripts/one_pass-from_off-pass_d.sh $pass $delay ${START_ANGLES[$pass]} ${OSCS[$pass]} $gain x,y,z
        else
            sbatch scripts/one_pass-from_off.sh $pass $delay ${START_ANGLES[$pass]} ${OSCS[$pass]} $gain x,y,z
        fi
    done
done
