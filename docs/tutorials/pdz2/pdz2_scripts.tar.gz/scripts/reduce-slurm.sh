#This is a script used for reducing PDZ2 EFX data. This script first combines the sixteen output mtzs together using expt_concat.py, and then runs careless, and then computes statistics. 

# Run this in the e35_PDZ folder, by calling sh reduce.sh .  

eval "$(conda shell.bash hook)"
conda activate laue-dials

for gain in 0.3 
do
    echo $gain
    python scripts/expt_concat.py $gain 
    sbatch scripts/careless-cdef-ohp-mlpl.sh $gain
    #sh scripts/stats_for_production.sh $gain
    
done


# the below script requires a conda environment with rs-booster (https://github.com/rs-station/rs-booster/tree/main/rsbooster) to run. 

# conda deactivate
# conda activate laue
# for gain in 0.3
# do
#     python scripts/wdm.py $gain
# done
