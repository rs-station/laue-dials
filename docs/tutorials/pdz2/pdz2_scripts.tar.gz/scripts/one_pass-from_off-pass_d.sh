#!/bin/bash
#SBATCH --job-name=PDZ_index_ld
#SBATCH -p seas_compute,shared,serial_requeue # partition (queue)
#SBATCH --mem 64G # memory pool for all cores
#SBATCH -t 0-00:50 # time (D-HH:MM)
#SBATCH -c 4
#SBATCH -o logs/index_%j.out        # Standard output
#SBATCH -e logs/index_%j.err        # Standard error

# An example script for processing an electric-field-stimulated time-resolved dataset. This script can be run using slurm. This script is different from one_pass-from_off.sh in that this one starts from stills.expt and stills.refl that have been processed using dials=3.14.0 and laue-dials=0.3.dev48+gacda0c2. There is a bug with laue.sequence_to_stills (https://github.com/rs-station/laue-dials/issues/49) that prevents us from proceeding with one_pass-from_off.sh. 

RUN_NO=${1}
TIME=${2}
CELL='"65.2,39.45,38.9,90.000,117.45,90.000"'
GAIN=${5}
CB_OP=${6}
GAIN_STR=$(echo "$GAIN" | tr . ,)
START_ANGLE=${3}
OSC=${4}
N=4 # Max multiprocessing

# Make needed directories
folder_name=gain_${GAIN_STR}_from_stills
mkdir $folder_name
mkdir $folder_name/dials_files_${RUN_NO}_${TIME}
cd $folder_name/dials_files_${RUN_NO}_${TIME}
rm *

FILE_INPUT_TEMPLATE="/n/hekstra_lab/projects/laue-dials-tests/e35_PDZ/images/e35${RUN_NO}_${TIME}_###.mccd"

eval "$(conda shell.bash hook)"
conda activate laue-dials
#rm indexed.expt indexed.refl laue.initial_solution.log

# to maintain spot positions and wavelengths between datasets, given that the crystal position does not change during the 
# timepoints, we copy the geometry and spot positions from the off dataset onto the timepoints. 
# we find and replace the images in the off dataset poly_refined for the current on dataset. 
sed s/e35${RUN_NO}_off_/e35${RUN_NO}_${TIME}_/g ../stills.expt > stills_rewritten.expt

laue.optimize_indexing stills_rewritten.expt ../stills.refl \
    output.experiments="optimized.expt" \
    output.reflections="optimized.refl" \
    output.log="laue.optimize_indexing.log" \
    wavelengths.lam_min=0.95 \
    wavelengths.lam_max=1.2 \
    reciprocal_grid.d_min=1.7 \
    nproc=$N

laue.refine optimized.* output.experiments="poly_refined.expt" output.reflections="poly_refined.refl" output.log="laue.poly_refined.log" nproc=$N

laue.predict poly_refined.* \
    output.reflections="predicted.refl" \
    output.log="laue.predict.log" \
    wavelengths.lam_min=0.95 \
    wavelengths.lam_max=1.2 \
    reciprocal_grid.d_min=1.7 \
    nproc=$N

laue.integrate poly_refined.expt predicted.refl output.filename="integrated.mtz" output.log="laue.integrate.log" nproc=$N

laue.compute_rmsds poly_refined.* > rmsds.log

# This is where laue_dials ends. The output file integrated.mtz can be merged in careless and refined in phenix to get a model
