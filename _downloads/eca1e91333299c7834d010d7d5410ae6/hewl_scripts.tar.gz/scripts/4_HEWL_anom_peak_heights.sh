for frames in 0090 0180 0360 0540 0720 0999 1080 1440 1800 2160 2520 2880 3049; do
    mtz_filename=../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_${frames}frames_phenix/Refine_2/HEWL_anom_${frames}frames_refine_2.mtz
    pdb_filename=../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_${frames}frames_phenix/Refine_2/HEWL_anom_${frames}frames_refine_2.pdb
    output_csv=../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_${frames}frames_phenix/HEWL_anom_${frames}frames_peak_heights.csv
	python anomalous_peak_heights.py ${mtz_filename} ${pdb_filename} [I,S] ${output_csv}
    csv_list+=(${output_csv})
done

python concatenate_anomalous_peak_csv.py ../HEWL_anom_phenix_final/HEWL_anom_peak_heights.csv "0090 0180 0360 0540 0720 0999 1080 1440 1800 2160 2520 2880 3049" "${csv_list[@]}"