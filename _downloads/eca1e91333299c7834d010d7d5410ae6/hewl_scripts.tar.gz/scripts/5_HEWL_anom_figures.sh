# Depiction of anomalous peaks via pymol
cp ../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_1440frames_phenix/Refine_2/HEWL_anom_1440frames_refine_2.mtz ../HEWL_anom_figures_final/anom_peak_pymol/
cp ../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_1440frames_phenix/Refine_2/HEWL_anom_1440frames_refine_2.pdb ../HEWL_anom_figures_final/anom_peak_pymol/
pymol HEWL_anom_peaks.pml

# Plot of anomalous peak height vs number of frames
bash HEWL_anom_peak_heights.sh
cp ../HEWL_anom_phenix_final/HEWL_anom_peak_heights.csv ../HEWL_anom_figures_final/anom_peak_vs_frames/
# remaining figure generation done in associated jupyter notebook

# Plot of cc_anom vs resolution
cp ../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_1440frames_phenix/HEWL_dwPEF_1440frames_xval_combined.mtz ../HEWL_anom_figures_final/ccanom_vs_res/
careless.ccanom -o ../HEWL_anom_figures_final/ccanom_vs_res/HEWL_anom_ccanom.csv ../HEWL_anom_figures_final/ccanom_vs_res/HEWL_dwPEF_1440frames_xval_combined.mtz
# remaining figure generation done in associated jupyter notebook

# Plot of cc_half vs resolution
cp ../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_1440frames_phenix/HEWL_dwPEF_1440frames_xval_combined.mtz ../HEWL_anom_figures_final/cchalf_vs_res/
careless.cchalf -o ../HEWL_anom_figures_final/cchalf_vs_res/HEWL_anom_cchalf.csv ../HEWL_anom_figures_final/cchalf_vs_res/HEWL_dwPEF_1440frames_xval_combined.mtz
# remaining figure generation done in associated jupyter notebook