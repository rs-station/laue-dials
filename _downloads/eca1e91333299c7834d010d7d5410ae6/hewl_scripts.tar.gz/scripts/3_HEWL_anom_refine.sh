for frames in 0090 0180 0360 0540 0720 0999 1080 1440 1800 2160 2520 2880 3049; do
	REFINE=../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_${frames}frames_phenix
	mkdir ${REFINE}/Refine_1 ${REFINE}/Refine_2
	cp custom_refinement_param_1.eff ${REFINE}/Refine_1/
	cp custom_refinement_param_2.eff ${REFINE}/Refine_2/
	sbatch sbatch_phenix_Refine.sh ${REFINE} ${frames}
done
