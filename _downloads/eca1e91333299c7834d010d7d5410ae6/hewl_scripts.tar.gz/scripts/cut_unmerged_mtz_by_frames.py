import os
import reciprocalspaceship as rs
import argparse



def parse_arguments():
    """Parse commandline arguments"""
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter, description=__doc__
    )
    parser.add_argument(
        "-i",
        "--inputmtz",
        required=True,
        help=(
            "MTZ containing unmerged intensities"
        ),
    )
    parser.add_argument(
        "-s",
        "--start",
        type=int,
        default=1,
        required=False,
        help=(
            "Starting frame/image/batch index (default: 1)"
        ),
    )
    parser.add_argument(
        "-e",
        "--end",
        type=int,
        required=True,
        help=(
            "Final batch/image/frame number to use (required)"
        ),
    )
    parser.add_argument(
        "-l",
        "--batch_label",
        required=False,
        default=None,
        help=(
            "Name of the MTZ column specifying the frame number"
        ),
    )

    return parser

def get_first_key_of_dtype(ds, dtype):
    matches = ds.dtypes[ds.dtypes == dtype].keys()
    for match in matches:
        return match
    return None


def main():
    # Parse commandline arguments
    args = parse_arguments().parse_args()


    start=args.start
    end=args.end    
    start_full=format(start, '04')
    end_full=format(end, '04')

    ds=rs.read_mtz(args.inputmtz)
    if args.batch_label is None:
        batch_label=  get_first_key_of_dtype(ds, 'Batch')
    else:
        batch_label = args.batch_label

    out_name=os.path.basename(args.inputmtz)[:-4]+"_frame_"+str(start_full)+"_"+str(end_full)+".mtz"
    
    print(f"\nSelecting data for reflections in images {start} to {end} (inclusive) of {args.inputmtz}, " + \
          f"using column name {batch_label} to identify images.\n")
    print(f"Writing to a new MTZ file named {out_name}.\n")

    out=ds.loc[(ds[batch_label]>= start) & (ds[batch_label]<= end),:].copy()
    out.write_mtz(out_name)

if __name__ == "__main__":
    main()
