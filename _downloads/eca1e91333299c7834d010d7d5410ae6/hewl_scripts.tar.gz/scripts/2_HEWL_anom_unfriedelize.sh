for frames in 0090 0180 0360 0540 0720 0999 1080 1440 1800 2160 2520 2880 3049; do
	MERGE=../HEWL_anom_careless_final/merge_HEWL_dwPEF_${frames}*
	cd ${MERGE}
	python ../../HEWL_anom_scripts_final/unfriedelize.py HEWL_dwPEF_${frames}frames_0.mtz HEWL_dwPEF_${frames}frames_1.mtz HEWL_dwPEF_${frames}frames_combined.mtz
	python ../../HEWL_anom_scripts_final/unfriedelize_xval.py HEWL_dwPEF_${frames}frames_xval_0.mtz HEWL_dwPEF_${frames}frames_xval_1.mtz HEWL_dwPEF_${frames}frames_xval_combined.mtz
	REFINE=../../HEWL_anom_phenix_final/HEWL_anom_poly_dwPEF_${frames}frames_phenix
	mkdir ${REFINE}
	mv *_combined.mtz ${REFINE}
	cd ../../HEWL_anom_scripts_final/
done
